#include "PIC16F628A_PRAGMA.INC" 
#define _XTAL_FREQ 4000000
#include <xc.h>

#define LCD_RS              RB2
#define LCD_E               RB3
#define LCD_D4              RB4
#define LCD_D5              RB5
#define LCD_D6              RB6
#define LCD_D7              RB7

#define LCD_RS_Tris         TRISB2
#define LCD_E_Tris          TRISB3
#define LCD_Tris_D4         TRISB4
#define LCD_Tris_D5         TRISB5
#define LCD_Tris_D6         TRISB6
#define LCD_Tris_D7         TRISB7

void pulseEnable() //Lcd ekran'a veri göndermek için gerekli olan clock darbesini uygulayan fonksiyon.
{
    LCD_E = 0;
    __delay_us(5);
    LCD_E = 1;
    __delay_us(5);
    LCD_E = 0;    
}

void LCD_Send4(unsigned const char data) //Lcd ekran'ın 4 portunu kullanarak veri gönderebilmek için kullanılan fonksiyon.
{
        LCD_D4 = ((data & 0b00010000) !=0);
        __delay_us(5);
        LCD_D5 = ((data & 0b00100000) !=0);
        __delay_us(5);
        LCD_D6 = ((data & 0b01000000) !=0);
        __delay_us(5);
        LCD_D7 = ((data & 0b10000000) !=0);
        
      /* Lcd ekranın 4 portunu kullanarak işlem yapabilmek için kullanılabilen bir başka fonksiyon.
       if((data & 0b00010000)==0)  LCD_D4=0;
        else                        LCD_D4=1;
        
        if((data & 0b00100000)==0)  LCD_D5=0;
        else                        LCD_D5=1;

        if((data & 0b01000000)==0)  LCD_D6=0;
        else                        LCD_D6=1;

        if((data & 0b10000000)==0)  LCD_D7=0;
        else                        LCD_D7=1;*/

        pulseEnable();
}

void LCD_Send(unsigned char data) //Lcd ekran'a 1 bytle'lık veri göndermek için gerekli olan fonksiyon
{ 
    LCD_Send4(data);
    data<<=4; 
    LCD_Send4(data);
    __delay_us(50);
}

void LCD_SendCommand(char cmd)  //Lcd ekran'a komut göndermek için gerekli olan fonksiyon
{
    LCD_RS = 0;
    LCD_Send(cmd);
}

void LCD_SendData(char data) //Lcd ekran'a veri göndermek için gerekli olan fonksiyon.
{
    LCD_RS = 1;
    LCD_Send(data);
}

void LCD_GotoXY(char row, char column) //Lcd ekranda hangi satır ve sütuna yazılacağını belirleyen fonksiyon.
{
    if (row == 0)       LCD_SendCommand(0x80 + column);
    else                LCD_SendCommand(0x80 + 0x40 + column);   
}
    
void LCD_Print (char str_row, char str_column, char* metin) 
{
    LCD_GotoXY(str_row, str_column);
    while(*metin)
        {
            LCD_SendData(*metin);
            metin++;
            __delay_ms(50);
        }        
}

void LCD_Initialize()           //Lcd ekranın kullanıma hazırlanması.
{ 
        __delay_ms(100);  
        LCD_RS_Tris = 0;      
        LCD_E_Tris = 0;       
        LCD_Tris_D4 = 0;   
        LCD_Tris_D5 = 0;   
        LCD_Tris_D6 = 0;   
        LCD_Tris_D7 = 0;  

        LCD_E = 0;
        LCD_RS = 0;
        LCD_D4 = 0;      
        LCD_D5 = 0;     
        LCD_D6 = 0;      
        LCD_D7 = 0;  

    __delay_ms(500);
    LCD_Send4(0b00110000);  
    __delay_ms(5);
    LCD_Send4(0b00110000); 
    __delay_us(500);
    LCD_Send4(0b00110000); 
    __delay_us(500);
    LCD_Send4(0b00100000);
}

void putch(char data)           //standart input output kütüphanesini kullanabilmek için gerekli olan fonksiyon.
{
 LCD_SendData(data);
}