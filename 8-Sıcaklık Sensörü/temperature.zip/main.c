#include "PIC16F628A_PRAGMA.INC" 
#define _XTAL_FREQ 4000000

#include <xc.h>
#include <stdio.h>
#include "Lcd_lib.h"
#include "DS18B20.h"

unsigned char str[6];

void main(void) 
{ 
    CMCON=0x07;
    unsigned char rom;

     LCD_Initialize();
     
     LCD_SendCommand(LCD_4BITMODE);             //İlk olarak function set ayarlanır        
     LCD_SendCommand(LCD_DISPLAYON);            //Display on/off control ayarlanır.
     LCD_SendCommand(LCD_ENTRYMODE);            //Entry mode ayarlanır ve bu sıranın korunması gerekir.  
    

        LCD_GotoXY(0, 0);

         if( OW_Reset()==0)  
            printf("HATA");
         /*else 
            printf("TAMAM");
        __delay_ms(1000);*/
        else
        {
            OW_Writebyte(0x33);
            rom = OW_Readbyte();
            str[0] = OW_Readbyte();
            str[1] = OW_Readbyte();
            str[2] = OW_Readbyte();
            str[3] = OW_Readbyte();
            str[4] = OW_Readbyte();
            str[5] = 10;
            
            

        LCD_SendCommand(LCD_CLEAR); 
        LCD_SendCommand(LCD_RETURNHOME);
        __delay_ms(2);

        LCD_GotoXY(0, 0);
         printf("sayi : %s",str);
        }
           
     while(1) continue;     
}