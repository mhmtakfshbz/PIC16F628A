#ifndef DS18B20
#define	DS18B20


unsigned char OW_Reset();
unsigned char OW_Readbyte(void);
void OW_Writebyte(char);

#endif