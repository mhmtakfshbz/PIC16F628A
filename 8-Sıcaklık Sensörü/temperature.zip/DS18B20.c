#include "PIC16F628A_PRAGMA.INC" 
#define _XTAL_FREQ 4000000
#include <xc.h>

#define OW_high TRISA0=1            //Hattı lojik 1'e çek.
#define OW_low RA0=0;TRISA0=0       //Hattı lojik 0'a çek.

unsigned char OW_Reset(void)
{
    OW_low;                       
    __delay_us(480);                // Reset komutu için bekle.
    OW_high;                        // Hattı lojik 1 yap.
    
   __delay_us(10);                  // Wait for presence pulse.
    
    if(RA0 != 1) return(0);           //RA0 1'e eşit değilse dön.

    __delay_us(60);

    if(RA0 != 0) return(0);           //RA0 0'a eşit değilse dön.
    
    __delay_us(240);

    if(RA0 != 1) return(0);           //RA0 1'e eşit değilse dön.

    return(1);                                      
}

void OW_Writebit(char bit)
{
    OW_low;
    __delay_us(5);

    if(bit==0)
    {
        __delay_us(60);
        OW_high;
    }
    else
    {
        OW_high;
        __delay_us(60);
    }
}

void OW_Writebyte(char data)
{
    char i;
    for(i=0; i<8; i++)
    {
        if(data & 0x01) 
            OW_Writebit(1);
        else
            OW_Writebit(0);
        
        data >>= 1;
    }
}

unsigned char OW_Readbit(void)
{ 
    char data;
    OW_low;
    __delay_us(2);
    OW_high;
    __delay_us(8);
    
    if(PORTAbits.RA0==0)
        data = 0;
    else 
        data = 1;

    __delay_us(60);
    return data;
}
unsigned char OW_Readbyte(void)
{
    unsigned char byte = 0;
    for (unsigned char i = 0; i < 8; i++) 
    {
        byte = byte >> 1;

        if(OW_Readbit() == 1)
            byte = byte | 0b10000000;
        else 
            byte = byte & 0b01111111;
    }
        return byte;
}