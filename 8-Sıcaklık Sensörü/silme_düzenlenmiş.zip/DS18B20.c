#include "PIC16F628A_PRAGMA.INC" 
#define _XTAL_FREQ 4000000
#include <xc.h>
#include <stdio.h>
#include "Lcd_Lib.h"

#define Ow_high TRISA0=1            //Hattı lojik 1'e çek.
#define Ow_low RA0=0;TRISA0=0       //Hattı lojik 0'a çek.

char OW_Reset(void)
{
    Ow_low;                       
    __delay_us(480);                // Reset komutu için bekle.
    Ow_high;                        // Hattı lojik 1 yap.
    
   __delay_us(12);                  // Wait for presence pulse.
    
    if(RA0!=1) return(0);           //RA0 1'e eşit değilse dön.

    __delay_us(60);

    if(RA0!=0) return(0);           //RA0 0'a eşit değilse dön.
    
    __delay_us(240);

    if(RA0!=1) return(0);           //RA0 1'e eşit değilse dön.

    return(1);                                      
}

char OW_Write0(char data)
{
}
char OW_Write1(char data)
{
    
}