#ifndef DS18B20
#define	DS18B20

char OW_Reset(void);

#endif