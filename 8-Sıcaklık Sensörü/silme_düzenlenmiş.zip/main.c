#include "PIC16F628A_PRAGMA.INC" 
#define _XTAL_FREQ 4000000

#include <xc.h>
#include <stdio.h>
#include "Lcd_Lib.h"
#include "DS18B20.h"


void main(void) 
{
    TRISA1=0;
    RA1=0;  
    CMCON=0x07;
    
     LCD_Initialize();
     
     LCD_SendCommand(LCD_4BITMODE);             //İlk olarak function set ayarlanır        
     LCD_SendCommand(LCD_DisplayOn);            //Display on/off control ayarlanır.
     LCD_SendCommand(LCD_ENTRYMODE);            //Entry mode ayarlanır ve bu sıranın korunması gerekir.  
    
     LCD_SendCommand(LCD_CLEAR); 
     LCD_SendCommand(LCD_RETURNHOME);
     __delay_ms(2);

    
     while(1)
     {  LCD_GotoXY(0, 0);

         if( OW_Reset()==0)  
            printf("HATA");
         else 
            printf("TAMAM");
        __delay_ms(1000);
     }         
}