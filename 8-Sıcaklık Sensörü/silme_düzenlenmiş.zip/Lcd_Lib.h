#ifndef Lcd_lib
#define	Lcd_lib

#define LCD_4BITMODE           0x28 //0010 1000     Lcd ekranı 4 bit modunda çalıştırır.
#define LCD_8BITMODE           0x38 //0011 1000     Lcd ekranı 8 bit modunda çalıştırır.

#define LCD_CLEAR              0x01 //0000 0001     Lcd ekranı temizler.
#define LCD_RETURNHOME         0x02 //0000 0010     Cursor başa gelir.

#define LCD_LINE1              0x80 //1000 0000     1.satıra gel.
#define LCD_LINE2              0xC0 //1100 0000     2.satıra gel.

#define LCD_DisplayOn          0x0F //0000 1111     Displayı ayarla. Cursor on/off, blink on/off.

#define LCD_TersYazdir         0x04 //0000 0100  
#define LCD_KayarakYazdir      0x07 //0000 0101 
#define LCD_ENTRYMODE          0x06 //0000 0110  
#define LCD_ENTRYMODE2         0x06 //0000 0111  

#define Lcd_Shift_Right        0x0C     //Lcd sağa kaydırarak yaz.
#define Lcd_Shift_Left         0x08     //Lcd sola kaydırarak yaz.

void pulseEnable(void);
void LCD_Initialize(void);
void LCD_Send(unsigned char);
void LCD_Send4(unsigned char);
void LCD_SendCommand(char);
void LCD_SendData(char);
void LCD_Print(char, char, char*);
void LCD_GotoXY(char, char);

#endif 