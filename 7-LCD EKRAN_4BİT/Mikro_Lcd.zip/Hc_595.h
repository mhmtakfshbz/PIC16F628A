#ifndef Hc_595
#define	Hc_595

void HC595_Initialize(void);
void HC595_PutByte(unsigned char);
void HC595_Load(void);
 
#endif 